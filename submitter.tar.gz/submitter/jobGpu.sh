#!/bin/bash

./gpuscript
date
nvidia-smi

