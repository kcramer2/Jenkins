#!/bin/bash


rm *.out
rm *.err
rm *.log
rm *.error
rm *.metrics
rm *.condor.sub
rm *.mp4
