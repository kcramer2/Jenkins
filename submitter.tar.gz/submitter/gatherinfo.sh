#!/bin/bash

hostname
date

